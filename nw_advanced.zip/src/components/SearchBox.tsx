import React, { useState, useMemo } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { MapPin } from 'lucide-react';
import { Location } from '@/types/location';

interface SearchBoxProps {
  locations: Location[];
  onSelect: (loc: Location) => void;
}

const SearchBox = ({ locations, onSelect }: SearchBoxProps) => {
  const [q, setQ] = useState('');
  const results = useMemo(() => {
    const qq = q.trim().toLowerCase();
    if (!qq) return locations.slice(0,8);
    return locations.filter(l => l.name.toLowerCase().includes(qq) || l.category.toLowerCase().includes(qq)).slice(0,8);
  }, [q, locations]);

  return (
    <div className="mb-3">
      <div className="flex gap-2">
        <Input placeholder="Search buildings or categories..." value={q} onChange={(e)=>setQ(e.target.value)} />
        <Button onClick={()=>{ setQ(''); }} variant="ghost" aria-label="Clear search">Clear</Button>
      </div>
      <div className="mt-2 grid gap-1">
        {results.map(r => (
          <button key={r.id} className="text-left p-2 rounded hover:bg-muted" onClick={()=>{ onSelect(r); setQ(''); }}>
            <div className="text-sm font-medium">{r.name}</div>
            <div className="text-xs text-muted-foreground">{r.category}</div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default SearchBox;
