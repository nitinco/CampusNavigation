import React, { useEffect, useRef } from 'react';
import L, { Map as LeafletMap } from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-routing-machine';
import 'leaflet-control-geocoder';
import 'leaflet.polylinedecorator';
import { Location } from '@/types/location';

interface MapViewProps {
  locations: Location[];
  selectedLocation: Location | null;
  onSelectLocation: (location: Location) => void;
  routePath: [number, number][] | null;
  userLocation: [number, number] | null;
  onRouteCalculated?: (info: {distance:number, duration:number, path:[number,number][]}) => void;
  theme?: 'light'|'dark';
}

const lightTiles = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
const darkTiles = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png';

const MapView = ({ locations, selectedLocation, onSelectLocation, routePath, userLocation, onRouteCalculated, theme='light' }: MapViewProps) => {
  const mapRef = useRef<LeafletMap | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const routingControlRef = useRef<any>(null);
  const routeLayerRef = useRef<any>(null);
  const animatorRef = useRef<any>(null);
  const walkerRef = useRef<any>(null);

  useEffect(()=>{
    if (!containerRef.current) return;
    if (!mapRef.current) {
      mapRef.current = L.map(containerRef.current, { zoomControl: true, center: [25.1860, 75.8060], zoom: 17 });
      // expose simple API for routing to window
      try{ (window as any)._nw_map_instance = mapRef.current; }catch(e){}
      L.tileLayer(theme === 'dark' ? darkTiles : lightTiles, { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' }).addTo(mapRef.current);
    }
    return ()=>{
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    }
  }, []);

  // theme switch for tiles
  useEffect(()=>{
    if (!mapRef.current) return;
    const layers = (mapRef.current as any)._layers;
    // remove existing tile layers
    mapRef.current.eachLayer((layer:any)=>{
      if (layer && layer._url && layer.options && layer.options.maxZoom) {
        mapRef.current?.removeLayer(layer);
      }
    });
    L.tileLayer(theme === 'dark' ? darkTiles : lightTiles, { maxZoom:19, attribution: '&copy; OpenStreetMap contributors' }).addTo(mapRef.current!);
  }, [theme]);

  // draw markers
  useEffect(()=>{
    if (!mapRef.current) return;
    // remove previous markers group
    const existing = (mapRef.current as any)._nw_markers;
    if (existing) {
      existing.remove();
    }
    const markers = L.layerGroup();
    (mapRef.current as any)._nw_markers = markers;
    locations.forEach(loc => {
      const m = L.marker(loc.coordinates as any, { title: loc.name });
      m.on('click', ()=> onSelectLocation(loc));
      m.bindPopup(`<strong>${loc.name}</strong><br/><small>${loc.category}</small>`);
      markers.addLayer(m);
    });
    markers.addTo(mapRef.current);
    // accessibility: set tabindex
    markers.eachLayer((layer:any)=>{
      const el = layer.getElement && layer.getElement();
      if (el) {
        el.setAttribute('tabindex','0');
        el.setAttribute('role','button');
      }
    });
  }, [locations]);

  // When routePath prop changes, draw route (this prop will be the raw path from our router)
  useEffect(()=>{
    if (!mapRef.current) return;
    // clear previous route layers/animator
    if (routeLayerRef.current) {
      try { routeLayerRef.current.remove(); } catch(e){}
      routeLayerRef.current = null;
    }
    if (animatorRef.current) {
      clearInterval(animatorRef.current);
      animatorRef.current = null;
    }
    if (walkerRef.current) {
      try { walkerRef.current.remove(); } catch(e) {}
      walkerRef.current = null;
    }

    if (!routePath || routePath.length < 2) return;

    // Create a polyline for the route
    const latlngs = routePath.map(p=>[p[0], p[1]] as [number,number]);
    const poly = L.polyline(latlngs, { color: '#2563eb', weight: 4, dashArray: '8,8' }).addTo(mapRef.current);
    routeLayerRef.current = poly;
    mapRef.current.fitBounds(poly.getBounds(), { padding: [24,24] });

    // Animated walker: loop along the polyline
    let idx = 0;
    const flat = latlngs;
    walkerRef.current = L.circleMarker(flat[0], { radius:6, fill:true, fillColor:'#fff', color:'#2563eb', weight:2 }).addTo(mapRef.current);
    const speedMsPerStep = 200; // controls speed; lower = faster
    animatorRef.current = setInterval(()=>{
      idx = (idx + 1) % flat.length;
      const latlng = flat[idx];
      walkerRef.current.setLatLng(latlng);
    }, speedMsPerStep);

    return ()=>{
      if (animatorRef.current) clearInterval(animatorRef.current);
    };
  }, [routePath]);

  // Programmatic routing using leaflet-routing-machine (hidden control)
  // Provide a helper function on the map instance for other components to call
  useEffect(()=>{
    if (!mapRef.current) return;
    (mapRef.current as any).calculateRoute = async (start:[number,number], end:[number,number]) => {
      // remove existing routing control
      if (routingControlRef.current) {
        try { routingControlRef.current.remove(); } catch(e){}
        routingControlRef.current = null;
      }
      // create routing control but do not add its UI; use it to compute route only
      const rc = (L as any).Routing.control({
        waypoints: [ L.latLng(start[0], start[1]), L.latLng(end[0], end[1]) ],
        router: (L as any).Routing.osrmv1({ serviceUrl: 'https://router.project-osrm.org/route/v1' }),
        show: false,
        addWaypoints: false,
        draggableWaypoints: false,
        fitSelectedRoutes: false,
        createMarker: ()=>{ return null; }
      });
      routingControlRef.current = rc;
      return new Promise((resolve, reject)=>{
        rc.on('routesfound', function(e:any){
          const routes = e.routes;
          if (!routes || !routes.length) {
            reject(new Error('No routes'));
            return;
          }
          const r = routes[0];
          // extract coordinates
          const coords:[number,number][] = r.coordinates.map((c:any)=>[c.lat, c.lng]);
          const distanceKm = Math.round((r.summary.totalDistance || r.summary.total_distance || 0)/100)/10; // km approx
          const durationMin = Math.ceil((r.summary.totalTime || r.summary.total_time || 0)/60); // minutes
          // Provide route coords as lat,lng pairs
          resolve({ distance: distanceKm, duration: durationMin, coords });
          // remove control (we used it only for computation)
          try{ rc.remove(); }catch(e){}
        });
        rc.on('routingerror', function(err:any){
          try{ rc.remove(); }catch(e){}
          reject(err);
        });
        rc.route();
      });
    };
  }, []);

  return (
    <div className="absolute inset-0">
      <div id="app-map" ref={containerRef} className="absolute inset-0 rounded-lg" />
    </div>
  );
};

export default MapView;
